﻿// MIS 3013 005 Spring 2022 Exam 3
// There are two problems in Exam 3.
Console.WriteLine("MIS 3013 005 Spring 2022 Exam 3");
