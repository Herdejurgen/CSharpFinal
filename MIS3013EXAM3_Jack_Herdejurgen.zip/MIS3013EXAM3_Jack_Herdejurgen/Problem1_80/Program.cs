﻿// MIS 3013 005 Spring 2022 Exam 3
// Problem 1: 80 points

using Problem1_80;

new Student("123", "Beth", 96);
new Student("126", "Jen", 86);
new Student("128", "David", 76.6);
new Student("129", "Ron", 60.6);
new Student("223", "Rose", 50.6);
new Student("226", "Bill", 90);
new Student("229", "Emily", 100);
new Student("323", "Carl", 86.6);
new Student("326", "Connor", 80.6);

foreach(Student stu in Student.students)
{
    stu.CalLetterGrade();
    stu.PrintOutinfor();
}

Console.WriteLine($"The average grade is: {Student.CalAverageGrade():F2}");

Console.WriteLine("The student with the highest grade is:");
Student.FindHighestGradeStudent().PrintOutinfor();


Console.WriteLine("MIS 3013 Exam 3 Problem 1");
