﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1_80
{
    public class Student
    {
        public string studentid;
        public string name;
        public double grade;
        public char lettergrade { get; set; }='Z';

        public static List<Student> students = new List<Student>();
        
        public Student()
        {

        }
        public Student(string id, string name, double grade)
        {
            this.studentid = id;
            this.name = name;
            this.grade = grade;

            Student.students.Add(this);
        }
        public void CalLetterGrade()
        {
            if (this.grade >= 90) { this.lettergrade = 'A'; }
            else if (this.grade >= 80) { this.lettergrade = 'B'; }
            else if (this.grade >= 70) { this.lettergrade = 'C'; }
            else if (this.grade >= 60) { this.lettergrade = 'D'; }
            else { this.lettergrade = 'F'; }
        }
        public void PrintOutinfor()
        {
            Console.WriteLine($"ID: {this.studentid} Name: {this.name} Final Grade: {this.grade} Letter Grade: {this.lettergrade}");
        }
        public static double CalAverageGrade()
        {
            double sumgrade = 0;
            foreach(Student stu in students)
            {
                sumgrade = sumgrade + stu.grade;
            }
            double average = sumgrade / students.Count;
            return average;
        }
        public static Student FindHighestGradeStudent()
        {
            Student highestgrade = new Student();
            highestgrade.grade = 0;
            foreach(Student stu in students)
            {

                if (stu.grade > highestgrade.grade)
                {
                    highestgrade = stu;
                }
            }
            return highestgrade;
        }
    }
}
