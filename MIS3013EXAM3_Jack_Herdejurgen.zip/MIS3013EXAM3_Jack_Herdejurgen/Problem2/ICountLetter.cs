﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem2_20
{
    public interface ICountLetter
    {
        public int CountLettersInTheName();// count how many letters are in the name string
    }
}
