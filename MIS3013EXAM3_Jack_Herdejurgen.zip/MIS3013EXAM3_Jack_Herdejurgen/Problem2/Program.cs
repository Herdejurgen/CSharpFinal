﻿// MIS 3013 005 Spring 2022 Exam 3
// Problem 2: 20 points

using Problem2_20;

new Student("123", "Beth Gates", 96);
new Student("126", "Carl Tom", 98);

foreach(Student stu in Student.students)
{
    Console.WriteLine(stu);
}
Console.WriteLine("MIS 3013 Exam 3 Problem 2");
