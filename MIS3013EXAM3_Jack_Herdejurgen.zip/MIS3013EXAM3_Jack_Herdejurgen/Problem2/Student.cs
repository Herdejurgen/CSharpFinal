﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem2_20
{
    public class Student:Person,ICountLetter
    {
        public string ID;
        public double grade;
        public Student(string ID, string name, double grade)
        {
            this.ID = ID;
            this.Name = name;
            this.grade = grade;

            Student.students.Add(this);

        }
        public static List<Student> students = new List<Student>();
        public int CountLettersInTheName()
        {
            int letters = 0;
            foreach(char c in this.Name.ToUpper())
            {
                if (c >= 'A' && c <= 'Z')
                {
                    letters++;
                }
            }
            return letters;
        }
        public override string ToString()
        {
            return String.Format($"ID: {this.ID} Name: {this.Name} Grade: {this.grade} Name length:{this.CountLettersInTheName()}");
            
        }
    }
}
